# Copyright 2024 Hewlett Packard Enterprise Development LP

import requests
import urllib3
import os
import sys
import logging
import ssl
from pyVim import connect, task
from pyVmomi import vim

# Suppressing SSL certificate verification warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Disable proxy environment variables to avoid interfering with requests
os.environ['no_proxy'] = '*'

# Configure logging
logging.basicConfig(filename='orchestrator.log',level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
stream_handler = logging.StreamHandler()
logging.getLogger().addHandler(stream_handler)
logger = logging.getLogger(__name__)


def getSessionID(vcsa):
    # Constructing the URL for the session ID endpoint
    sessionIDurl = f"https://{vcsa['ipAddress']}/api/session"

    try:
        # Making a POST request to obtain the session ID
        res = requests.post(sessionIDurl, auth=(vcsa["userName"], vcsa["password"]), verify=False)

        if res.status_code == 201:
            # If the request is successful, print success message and return the session ID
            logger.info("Successfully obtained the session ID")
            return res.headers.get('vmware-api-session-id')
        else:
            # If the request fails, print error details
            logger.error("Failed to get session ID")
            logger.error("Error code: %s", res.status_code)
            logger.error("Error message: %s", res.json()["message"])
            return None

    except Exception as e:
        # Handle exceptions
        logger.error("Error: %s", e)
        return None

def get_host_id(session_id, vcenter_ip, host_name):
    url = f"https://{vcenter_ip}/rest/vcenter/host"
    headers = {
        'vmware-api-session-id': session_id,
        'Content-Type': 'application/json'
    }
    params = {
        'filter.names': host_name
    }
    try:
        response = requests.get(url, headers=headers, params=params, verify=False)
        if response.status_code == 200:
            host_list = response.json()
            if host_list.get('value'):
                return host_list['value'][0]['host']
            else:
                logger.error("No host found with name %s", host_name)
                return None
        else:
            logger.error("Failed to get host ID for %s. Status code: %s", host_name, response.status_code)
            logger.error(response.text)
            return None
    except Exception as e:
        logger.error("An error occurred while fetching host ID for %s: %s", host_name, e)
        return None

def put_host_in_exit_maintenance_mode(vcenter_ip, username, password, source_host_name):
    TIMEOUT = 2000
    try:
        context = ssl._create_unverified_context()
        my_cluster = connect.SmartConnect(host=vcenter_ip, port=443, user=username, pwd=password, sslContext=context)
        searcher = my_cluster.content.searchIndex
        host = searcher.FindByDnsName(dnsName=source_host_name, vmSearch=False)
        logger.info("Putting Host '%s' in exit maintenance mode", source_host_name)

        if host:
            task1 = host.ExitMaintenanceMode(TIMEOUT)
            task.WaitForTask(task1)
            logger.info(f"{host.name} is in exit maintenance mode.")
        else:
            logger.error("Host not found or search failed.")
        connect.Disconnect(my_cluster)
    except Exception as e:
        logger.error(f"Failed to put host in exit maintenance mode: {e}")
        sys.exit(1)

def get_local_datastore_vm_list(vcenter_ip, username, password, source_host_name_local, local_datastore_name):
    local_datastore_vm = {}
    datastore = None
    vm_count = 0
    try:
        # Connect to vCenter Server
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS)
        ssl_context.verify_mode = ssl.CERT_NONE
        service_instance = connect.SmartConnect(host=vcenter_ip, user=username, pwd=password, sslContext=ssl_context)

        # Retrieve VM properties
        content = service_instance.RetrieveContent()
        for ds in content.viewManager.CreateContainerView(content.rootFolder, [vim.Datastore], True).view:
            if ds.name == local_datastore_name:
                datastore = ds
                break
        
        if datastore:
            # Get VMs in datastore
            for vm in datastore.vm:
                vm_count = vm_count + 1
                print("VM Name:", vm.name)
                local_datastore_vm[vm._moId] = {"vm_count": vm_count, "name": vm.name}
        else:
            print("Datastore not found")
        
        for vm_id, vm_info in local_datastore_vm.items():
            logger.info("VM with %d local datastore attached found on %s: %s", vm_info['vm_count'], source_host_name_local, vm_info['name'])

        
        return local_datastore_vm

    except Exception as e:
        logger.error("An error occurred while connecting: %s", str(e))
        sys.exit(1)
    finally:
        # Disconnect from vCenter Server
        connect.Disconnect(service_instance)

def power_on_vm(session_id, vcenter_ip, vm_id, vm_name):
    url = f"https://{vcenter_ip}/rest/vcenter/vm/{vm_id}/power/start"
    headers = {
        'vmware-api-session-id': session_id,
        'Content-Type': 'application/json'
    }
    try:
        response = requests.post(url, headers=headers, verify=False)
        if response.status_code == 200:
            logger.info("Successfully powered on VM '%s' with ID %s.", vm_name, vm_id)
        else:
            logger.error("Failed to power on VM '%s' with ID %s. Status code: %s", vm_name, vm_id, response.status_code)
            logger.error(response.text)
    except Exception as e:
        logger.error("An error occurred while powering on VM '%s' with ID %s: %s", vm_name, vm_id, e)

def main():
    if len(sys.argv) != 6:
        print("Usage: python3 script.py <vcenter_ip> <username> <password> <source_host_name>")
        sys.exit(1)

    # Extracting command-line arguments
    vcenter_ip = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    source_host_name = sys.argv[4]
    local_datastore_name = sys.argv[5]
    #destination_host_name = sys.argv[5]

    # Define vCenter Server details
    vcsa = {
        "ipAddress": vcenter_ip,
        "userName": username,
        "password": password
    }

    # Get the session ID
    session_id = getSessionID(vcsa)
    if session_id:
        logger.info("Session ID: %s", session_id)

        # Get the host ID for the source host
        source_host_id = get_host_id(session_id, vcenter_ip, source_host_name)
        if source_host_id:
            # Put the source host in maintenance mode
            put_host_in_exit_maintenance_mode(vcenter_ip, username, password, source_host_name)

            # Identify VMs with Local datastore
            local_datastore_vm_list = get_local_datastore_vm_list(vcenter_ip, username, password, source_host_name, local_datastore_name)

            # Power on Local datastore based VMs on the destination host after migration
            if local_datastore_vm_list:
                for local_vm_id, local_vm in local_datastore_vm_list.items():
                    if "strbk" in local_vm['name']:
                        power_on_vm(session_id, vcenter_ip, local_vm_id, local_vm['name'])
            else:
                logger.info("No Local datastore based VMs were available to %s, nothing to power on.", source_host_name)

        else:
            logger.error("Failed to retrieve host ID for %s", source_host_name)
    else:
        logger.error("Failed to obtain session ID")

if __name__ == '__main__':
    main()
