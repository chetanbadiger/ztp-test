# Copyright 2023 Hewlett Packard Enterprise Development LP
import argparse
import csv
import time
import logging
import sys
import paramiko

logging.basicConfig(filename='orchestrator.log',level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
stream_handler = logging.StreamHandler()
logging.getLogger().addHandler(stream_handler)
logger = logging.getLogger(__name__)

class EsxiUpgradeService:
    """Class representing an automating ESXi Upgrade process"""
    def ssh_execute_command(ssh, command):
        """ Function printing executing ESXi CLI commands """
        _, stdout, stderr = ssh.exec_command(command)
        return stdout.read().decode(), stderr.read().decode()

    def check_maintenance_mode(ssh_client):
        """ Function returns zero if ESXi host enters maintenance mode"""
        check_return_code = 0
        try:
            command =  "esxcli system maintenanceMode get"
            stdout, stderr = EsxiUpgradeService.ssh_execute_command(ssh_client, command)
            if len(stderr) != 0:
                check_return_code = 1
                sys.exit(check_return_code)
            
            if "Disabled" in stdout:
                check_return_code = 1
                            
            return check_return_code
        except Exception as e:
            logging.error(
                ("Failed to execute the enter maintenance mode. Exception occurred: %s"), e
            )
    
    def check_esxi_version(ssh_client):
        """ Function returns zero if Verify the ESXi version"""
        check_esxi_version_return_code = 0
        try:
            command =  "vmware -v"
            stdout, stderr = EsxiUpgradeService.ssh_execute_command(ssh_client, command)
            if len(stderr) != 0:
                check_esxi_version_return_code = 1
                sys.exit(check_esxi_version_return_code)
                     
            return check_esxi_version_return_code, stdout
        except Exception as e:
            logging.error(
                ("Failed to execute the verify the ESXi version. Exception occurred: %s"), e
            )

    def reboot_host(ssh_client, host):
        """ Function is for rebooting ESXi host if rebooting requires after the ESXi host patch upgrade """
        reboot_command = "reboot"
        _, __ = EsxiUpgradeService.ssh_execute_command(ssh_client, reboot_command)
        logging.info(f"ESXi host {host} Reboot is in progress ... wait for 5 minutes")
        time.sleep(500)

    def post_upgrade(host, username, password):
        """ Function returns the generated CSV report of VIBs installed list after  ESXi upgrade the host """
        post_upgrade_return_code = 0
        vib_error = None
        esxi_version = None
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)

            _, esxi_version = EsxiUpgradeService.check_esxi_version(ssh_client)
            logging.info(f"Successfully completed the ESXi host {esxi_host} upgrade version {esxi_version}.")

            vib_signature_cmd =  "esxcli software vib signature verify"
            vib_report, vib_error = EsxiUpgradeService.ssh_execute_command(ssh_client, vib_signature_cmd)
            
            if len(vib_error) != 0:
                post_upgrade_return_code = 1
                logging.error(f"Error on execute the vib signature command {vib_error}")
                sys.exit(post_upgrade_return_code)
        
            rows = vib_report.strip().split('\n')
            rows = [row.split('\t') for row in rows]
            
            vib_status_file = f"vib_status_{host}.csv"
            with open(vib_status_file, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerows(rows)
      
        except Exception as e:
            post_upgrade_return_code = 1
            logging.error(
                ("Failed to execute the Post ESXi upgrade commands. Exception occurred: %s"), e
            )
            sys.exit(post_upgrade_return_code)
        
        finally:
            ssh_client.close()
    
      
    def esxi_vibs_upgrade(host, username, password, depot_path):
        """ Function returns the step-by-step upgrading ESXi patch of the host """
        upgrade_return_code = 0
        check_maintenance_mode = 0
        vib_error = None
        esxi_version = None
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)
            
            _, esxi_version = EsxiUpgradeService.check_esxi_version(ssh_client)
            logging.info(f"Before upgrading ESXI host {esxi_host} version {esxi_version}.")

            check_maintenance_mode =  EsxiUpgradeService.check_maintenance_mode(ssh_client)
            if check_maintenance_mode:
                logging.error(f"{esxi_host} Host not in maintenance mode.....Aborting upgrade")
                sys.exit(check_maintenance_mode)
            
            upgrade_esxi_vib_cmd =  f"esxcli software vib update -d {depot_path}"
            vib_stdout, vib_error = EsxiUpgradeService.ssh_execute_command(ssh_client, upgrade_esxi_vib_cmd)
            
            if vib_error:
                upgrade_return_code = 1
                logging.error(f"Error on execute the vib install command {vib_error}")
                sys.exit(upgrade_return_code)

            if "Reboot Required: true" in vib_stdout:
                EsxiUpgradeService.reboot_host(ssh_client, host)
                reachable = False
                while not reachable:
                    try:
                        ssh_client.connect(host, username=username, password=password)
                        ping_command = f"ping -c 1 {host}"
                        __, _ = EsxiUpgradeService.ssh_execute_command(ssh_client, ping_command)
                        reachable = True
                        break
                    except Exception as e:
                        logging.info(
                            ("Host is not reachable, retrying .... %s"), e
                        )
                        time.sleep(10)

            return upgrade_return_code
        except Exception as e:
            upgrade_return_code = 1
            logging.exception(
                ("Failed to execute the Upgrade ESXi vib commands. Exception occurred: %s"), e
            )
            
            sys.exit(upgrade_return_code)
 
        finally:
            ssh_client.close()
  
    def esxi_apply_upgrade(host, username, password, depot_path, software_spec):
        """ Function returns the step-by-step upgrading ESXi patch of the host """
        esxi_upgrade_return_code = 0
        check_maintenance_mode = 0
        vib_error = None
        esxi_version = None
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)
            
            _, esxi_version = EsxiUpgradeService.check_esxi_version(ssh_client)
            logging.info(f"Before upgrading ESXI host {esxi_host} version {esxi_version}.")

            check_maintenance_mode =  EsxiUpgradeService.check_maintenance_mode(ssh_client)
            if check_maintenance_mode:
                logging.error(f"{esxi_host} Host not in maintenance mode.....Aborting upgrade")
                sys.exit(check_maintenance_mode)
            
            upgrade_esxi_cmd =  f"esxcli software apply -d {depot_path} -s {software_spec}"
            vib_stdout, vib_error = EsxiUpgradeService.ssh_execute_command(ssh_client, upgrade_esxi_cmd)
            
            if vib_error:
                esxi_upgrade_return_code = 1
                logging.error(f"Error on execute the vib install command {vib_error}")
                sys.exit(esxi_upgrade_return_code)

            if "Reboot Required: true" in vib_stdout:
                EsxiUpgradeService.reboot_host(ssh_client, host)
                reachable = False
                while not reachable:
                    try:
                        ssh_client.connect(host, username=username, password=password)
                        ping_command = f"ping -c 1 {host}"
                        __, _ = EsxiUpgradeService.ssh_execute_command(ssh_client, ping_command)
                        reachable = True
                        break
                    except Exception as e:
                        logging.info(
                            ("Host is not reachable, retrying .... %s"), e
                        )
                        time.sleep(10)

            return esxi_upgrade_return_code
        except Exception as e:
            esxi_upgrade_return_code = 1
            logging.exception(
                ("Failed to execute the Upgrade ESXi vib commands. Exception occurred: %s"), e
            )
            
            sys.exit(esxi_upgrade_return_code)
 
        finally:
            ssh_client.close()
            
if __name__ == "__main__":
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument("esxi_host")
        parser.add_argument("esxi_user")
        parser.add_argument("esxi_password")
        parser.add_argument("depot_path")
        parser.add_argument("software_spec")
        args = parser.parse_args()
    
        return_code = 0
            
        esxi_host = args.esxi_host
        esxi_user = args.esxi_user
        esxi_password = args.esxi_password
        depot_file_path = args.depot_path
        software_spec_json = args.software_spec
        
        return_code = EsxiUpgradeService.esxi_apply_upgrade(esxi_host, esxi_user, esxi_password, depot_file_path, software_spec_json)
        
        if return_code:
            sys.exit(return_code)
                
        EsxiUpgradeService.post_upgrade(esxi_host, esxi_user, esxi_password)
        logging.info(f"After upgrade generated csv report for VIBs list installation status of the ESXi host {esxi_host}")
           
    except Exception as e:
        logging.error(
            "Execution failed, Could not complete upgrade for ESXi: %s", e
        )
        sys.exit(e)