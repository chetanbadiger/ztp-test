# Copyright 2023 Hewlett Packard Enterprise Development LP
import argparse
import csv
import time
import logging
import sys
import math
import paramiko

logging.basicConfig(filename='orchestrator.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
class EsxiLCMService:
    """Class representing an automating ESXi Upgrade process"""
    def ssh_execute_command(ssh, command):
        """ Function printing executing ESXi CLI commands """
        _, stdout, stderr = ssh.exec_command(command)
        return stdout.read().decode(), stderr.read().decode()

    def check_maintenance_mode(ssh_client):
        """ Function returns zero if ESXi host enters maintenance mode"""
        check_return_code = 0
        try:
            command =  "esxcli system maintenanceMode get"
            stdout, stderr = EsxiLCMService.ssh_execute_command(ssh_client, command)
            if len(stderr) != 0:
                check_return_code = 1
                sys.exit(check_return_code)
            
            if "Disabled" in stdout:
                check_return_code = 1
                            
            return check_return_code
        except Exception as e:
            logging.error(
                ("Failed to execute the enter maintenance mode. Exception occurred: %s"), e
            )

    def exit_maintenance_mode(ssh_client):
        """ Function returns zero if ESXi host exit maintenance mode """
        exit_return_code = 0
        try:
            command =  "esxcli system maintenanceMode set --enable false"
            _, stderr = EsxiLCMService.ssh_execute_command(ssh_client, command)

            if len(stderr) != 0:
                exit_return_code = 1
                sys.exit(exit_return_code)
            
            logging.info("Successfully done exit maintenance mode")     
            return exit_return_code
        except Exception as e:
            logging.error(
                ("Failed to execute the exit maintenance mode. Exception occurred: %s"), e
            )
    
    def check_esxi_version(ssh_client):
        """ Function returns zero if Verify the ESXi version"""
        check_esxi_version_return_code = 0
        try:
            command =  "vmware -v"
            stdout, stderr = EsxiLCMService.ssh_execute_command(ssh_client, command)
            if len(stderr) != 0:
                check_esxi_version_return_code = 1
                sys.exit(check_esxi_version_return_code)
                     
            return check_esxi_version_return_code, stdout
        except Exception as e:
            logging.error(
                ("Failed to execute the verify the ESXi version. Exception occurred: %s"), e
            )

    def precheck_higher_version_upgrade(ssh_client, depot_path):
        """ From the KB article reference https://kb.vmware.com/s/article/88877; Function is for remove the component as BCM-vmware-storcli64 for higher versions such 8.x"""
        precheck_version_return_code = 0
        check_version_return_code = 0
        try:
            check_version_return_code = EsxiLCMService.check_esxi_higher_version(ssh_client, depot_path)
            if check_version_return_code == 0:
                remove_commponent_cmd =  "esxcli software component remove -n BCM-vmware-storcli64"
                _, remove_commponent_stderr = EsxiLCMService.ssh_execute_command(ssh_client, remove_commponent_cmd)
                time.sleep(30)
                            
            if len(remove_commponent_stderr) != 0:
                precheck_version_return_code = 1
                logging.error(f"Error on execute the remove component command {remove_commponent_stderr}")
                sys.exit(precheck_version_return_code)
            
            return precheck_version_return_code

        except Exception as e:
            logging.error(
                ("Failed to execute the remove component command. Exception occurred: %s"), e
            )
            sys.exit(1) 

    def check_esxi_higher_version(ssh_client, depot_path):
        """ Function will compares ESXi depot file version with currently installed version."""
        compare_version_return_code = 0
        try:
            target_version_depot_arr = depot_path.split("/")
            target_version_arr = target_version_depot_arr[-1].split("-")
            if "HPE" in target_version_arr:
                target_version = round(target_version_arr[2], -2)
            else:
                vm_target_version_arr = target_version_arr[2].split("U")
                target_version =  vm_target_version_arr[0]

            _, current_version = EsxiLCMService.check_esxi_version(ssh_client)
            current_version_arr = current_version.split(" ")
            current_version = round(current_version_arr[2], -2)
            
            if current_version < target_version:
                logging.info(f"Target version {target_version_arr[2]} is higher than currently installed version {current_version_arr[2]} ")
                compare_version_return_code = 0
            else:
                logging.info(f"Target version {target_version_arr[2]} is same currently installed version {current_version_arr[2]} ")
                compare_version_return_code = 1

            return compare_version_return_code
        except Exception as e:
            logging.error(
                ("Failed to execute the ESXi version upgrade command. Exception occurred: %s"), e
            )
            sys.exit(1)

    def check_vsan_health(host, username, password):
        """ Function returns the zero, 0 means vSAN health is green, 1 means vSAN health is red """
        vsan_health_return_bool = False
        vsan_health_return_code = 0
        vsan_health_error = None
        vsan_health_lst = []
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)

            vsan_health_cmd =  "esxcli vsan health cluster list"
            vsan_health_report, vsan_health_error = EsxiLCMService.ssh_execute_command(ssh_client, vsan_health_cmd)
            time.sleep(30)

            if len(vsan_health_error) != 0:
                logging.error(f"Error on execute the vSAN health command {vsan_health_error}")
                sys.exit(1)
            
            for i, line in enumerate(vsan_health_report.splitlines()):
                    if "Physical disk" in line:
                        vsan_health_lst.append(line)
                    if "Cluster" in line:
                        vsan_health_lst.append(line)
                    if "Data" in line:
                        vsan_health_lst.append(line)
                    if "Performance service" in line:
                        vsan_health_lst.append(line)
            
            vsan_health_return_bool = all("green" in word for word in vsan_health_lst)
            if vsan_health_return_bool:
                vsan_health_return_code = 0
            else:
                vsan_health_return_code = 1
            return vsan_health_return_code
        
        except Exception as e:
            logging.error(
                ("Failed to execute the vSAN health command. Exception occurred: %s"), e
            )
            sys.exit(1)     
        finally:
            ssh_client.close()
             
    def reboot_host(ssh_client, host):
        """ Function is for rebooting ESXi host if rebooting requires after the ESXi host patch upgrade """
        reboot_command = "reboot"
        _, __ = EsxiLCMService.ssh_execute_command(ssh_client, reboot_command)
        logging.info(f"ESXi host {host} Reboot is in progress ... wait for 5 minutes")
        time.sleep(500)
    
    def post_upgrade(host, username, password):
        """ Function returns the generated CSV report of VIBs installed list after  ESXi upgrade the host """
        post_upgrade_return_code = 0
        vib_error = None
        esxi_version = None
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)

            _, esxi_version = EsxiLCMService.check_esxi_version(ssh_client)
            logging.info(f"Successfully completed the ESXi host {esxi_host} upgrade version {esxi_version}.")

            vib_signature_cmd =  "esxcli software vib signature verify"
            vib_report, vib_error = EsxiLCMService.ssh_execute_command(ssh_client, vib_signature_cmd)
            
            if len(vib_error) != 0:
                post_upgrade_return_code = 1
                logging.error(f"Error on execute the vib signature command {vib_error}")
                sys.exit(post_upgrade_return_code)
        
            rows = vib_report.strip().split('\n')
            rows = [row.split('\t') for row in rows]
            
            vib_status_file = f"vib_status_{host}.csv"
            with open(vib_status_file, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerows(rows)
      
        except Exception as e:
            post_upgrade_return_code = 1
            logging.error(
                ("Failed to execute the Post ESXi upgrade commands. Exception occurred: %s"), e
            )
            sys.exit(post_upgrade_return_code)
        
        finally:
            ssh_client.close()
    
    def esxi_downgrade(host, username, password, depot_path):
        """ Function returns the step-by-step downgrading ESXi patch or version of the host """
        downgrade_return_code = 0
        check_maintenance_mode = 0
        esxi_version = None
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)
            
            _, esxi_version = EsxiLCMService.check_esxi_version(ssh_client)
            logging.info(f"Before downgrading ESXI host {esxi_host} version {esxi_version}.")

            check_maintenance_mode =  EsxiLCMService.check_maintenance_mode(ssh_client)
            if check_maintenance_mode:
                logging.error(f"If maintenance returns one, then status is disabled.: {check_maintenance_mode}")
                sys.exit(check_maintenance_mode)
            
            logging.info(f"If maintenance returns zero, then status is enabled.: {check_maintenance_mode}") 
            
            if "HPE" in depot_path:
                get_esxi_profile_cmd = f"esxcli software sources profile list -d {depot_path} --allow-downgrades | grep HPE-Custom-AddOn | awk " + "{'print $1'}"
            else:
                get_esxi_profile_cmd = f"esxcli software sources profile list -d {depot_path} --allow-downgrades | grep standard | awk " + "{'print $1'}"
            
            get_esxi_profile_stdout, get_esxi_profile_error = EsxiLCMService.ssh_execute_command(ssh_client, get_esxi_profile_cmd)
        
            if get_esxi_profile_error:
                downgrade_return_code = 1
                logging.error(f"Error on execute the get the profile command {get_esxi_profile_error}")
                sys.exit(downgrade_return_code)
         
            for i, get_esxi_profile_line in enumerate(get_esxi_profile_stdout.splitlines()):
                downgrade_esxi_version_cmd =  f"esxcli software profile update -d {depot_path} -p {get_esxi_profile_line}"
                downgrade_esxi_version_stdout, downgrade_esxi_version_error = EsxiLCMService.ssh_execute_command(ssh_client, downgrade_esxi_version_cmd)
                time.sleep(30)
                if downgrade_esxi_version_error:
                    downgrade_return_code = 1
                    logging.error(f"Error on execute the esxi version downgrade command {downgrade_esxi_version_error}")
                    sys.exit(downgrade_return_code)

                if "Reboot Required: true" in downgrade_esxi_version_stdout:
                    EsxiLCMService.reboot_host(ssh_client, host)
                    reachable = False
                    while not reachable:
                        try:
                            ssh_client.connect(host, username=username, password=password)
                            ping_command = f"ping -c 1 {host}"
                            __, _ = EsxiLCMService.ssh_execute_command(ssh_client, ping_command)
                            reachable = True
                            break
                        except Exception as e:
                            logging.info(
                                ("Host is not reachable, retrying .... %s"), e
                            )
                            time.sleep(10)
            
            downgrade_return_code = EsxiLCMService.exit_maintenance_mode(ssh_client)
            if downgrade_return_code == 1:
                logging.info(f"Failed the Exit Maintenance mode of {host}")
                sys.exit(downgrade_return_code)

            return downgrade_return_code
        except Exception as e:
            downgrade_return_code = 1
            logging.exception(
                ("Failed to execute the Downgrade ESXi commands. Exception occurred: %s"), e
            )
            sys.exit(downgrade_return_code)
 
        finally:
            ssh_client.close()

    def esxi_upgrade(host, username, password, depot_path):
        """ Function returns the step-by-step upgrading ESXi patch of the host """
        upgrade_return_code = 0
        check_maintenance_mode = 0
        esxi_version = None
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)
            
            _, esxi_version = EsxiLCMService.check_esxi_version(ssh_client)
            logging.info(f"Before upgrading ESXI host {esxi_host} version {esxi_version}.")

            check_maintenance_mode =  EsxiLCMService.check_maintenance_mode(ssh_client)
            if check_maintenance_mode:
                logging.error(f"If maintenance returns one, then status is disabled.: {check_maintenance_mode}")
                sys.exit(check_maintenance_mode)
            
            logging.info(f"If maintenance returns zero, then status is enabled.: {check_maintenance_mode}") 
            
            if "HPE" in depot_path:
                get_esxi_profile_cmd = f"esxcli software sources profile list -d {depot_path} | grep HPE-Custom-AddOn | awk " + "{'print $1'}"
            else:
                get_esxi_profile_cmd = f"esxcli software sources profile list -d {depot_path} | grep standard | awk " + "{'print $1'}"
                
            get_esxi_profile_stdout, get_esxi_profile_error = EsxiLCMService.ssh_execute_command(ssh_client, get_esxi_profile_cmd)
            

            if get_esxi_profile_error:
                upgrade_return_code = 1
                logging.error(f"Error on execute the get the profile command {get_esxi_profile_error}")
                sys.exit(upgrade_return_code)
         
            for i, get_esxi_profile_line in enumerate(get_esxi_profile_stdout.splitlines()):
                upgrade_esxi_version_cmd =  f"esxcli software profile update -d {depot_path} -p {get_esxi_profile_line}"
                upgrade_esxi_version_stdout, upgrade_esxi_version_error = EsxiLCMService.ssh_execute_command(ssh_client, upgrade_esxi_version_cmd)
                time.sleep(30)
            
                if upgrade_esxi_version_error:
                    upgrade_return_code = 1
                    logging.error(f"Error on execute the esxi version upgrade command {upgrade_esxi_version_error}")
                    sys.exit(upgrade_return_code)
            
                if "Reboot Required: true" in upgrade_esxi_version_stdout:
                    EsxiLCMService.reboot_host(ssh_client, host)
                    reachable = False
                    while not reachable:
                        try:
                            ssh_client.connect(host, username=username, password=password)
                            ping_command = f"ping -c 1 {host}"
                            __, _ = EsxiLCMService.ssh_execute_command(ssh_client, ping_command)
                            reachable = True
                            break
                        except Exception as e:
                            logging.info(
                                ("Host is not reachable, retrying .... %s"), e
                            )
                            time.sleep(10)
            
            upgrade_return_code = EsxiLCMService.exit_maintenance_mode(ssh_client)
            if upgrade_return_code == 1:
                logging.info(f"Failed the Exit Maintenance mode of {host}")
                sys.exit(upgrade_return_code)

            return upgrade_return_code
        except Exception as e:
            upgrade_return_code = 1
            logging.exception(
                ("Failed to execute the Upgrade ESXi commands. Exception occurred: %s"), e
            )
            
            sys.exit(upgrade_return_code)
 
        finally:
            ssh_client.close()
     
