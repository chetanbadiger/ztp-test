import pyVmomi
import pyVim
from pyVmomi import vmodl, vim
from pyVim.connect import SmartConnect, Disconnect
import sys
import os
import ssl
import logging
import atexit
import argparse
import getpass
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "library"))
from vsan import vsanapiutils

logging.basicConfig(filename='orchestrator.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
stream_handler = logging.StreamHandler()
logging.getLogger().addHandler(stream_handler)
logger = logging.getLogger(__name__)

class CheckVCAvSANHealthService:
    
    def getClusterInstance(clusterName, serviceInstance):
        content = serviceInstance.RetrieveContent()
        searchIndex = content.searchIndex
        datacenters = content.rootFolder.childEntity
        for datacenter in datacenters:
            cluster = searchIndex.FindChild(datacenter.hostFolder, clusterName)
            if cluster is not None:
                return cluster
        return None
    
    def check_vca_vsan_health(vc_host, vc_user, vc_password, vc_clusterName, vc_source_host_name):
        """ Function returns the zero, 0 means VCA vSAN health is green, 1 means vSAN health is red """
        context = None
        vca_vsan_health_return_code = 0
        vc_port = 443
        try:
            if sys.version_info[:3] > (2,7,8):
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE

            si = SmartConnect(host=vc_host,
                                user=vc_user,
                                pwd=vc_password,
                                port=vc_port,
                                sslContext=context)

            aboutInfo = si.content.about
            apiVersion = vsanapiutils.GetLatestVmodlVersion(vc_host, vc_port)
            if aboutInfo.apiType == 'VirtualCenter':
                # Get vSAN health system from the vCenter Managed Object references.
                vcMos = vsanapiutils.GetVsanVcMos(
                        si._stub, context=context, version=apiVersion)
                vhs = vcMos['vsan-cluster-health-system']
                cluster = CheckVCAvSANHealthService.getClusterInstance(vc_clusterName, si)
                if cluster is None:
                    logger.info("Cluster %s is not found for %s", vc_clusterName, vc_host)
                    sys.exit(1)

                healthSummary = vhs.QueryClusterHealthSummary(
                    cluster=cluster, includeObjUuids=True) 
                clusterStatus = healthSummary.clusterStatus
                if "red" in healthSummary.overallHealth:
                    logger.error("VCA: Overall cluster %s Health status: %s", vc_clusterName, healthSummary.overallHealth)
                    vca_vsan_health_return_code = 1
                else:
                    logger.info("VCA: Overall cluster %s Health status: %s", vc_clusterName, healthSummary.overallHealth)
                    vca_vsan_health_return_code = 0
                
                if "red" in clusterStatus.status:
                    logger.error("VCA: Cluster %s Status: %s", vc_clusterName, clusterStatus.status)
                    vca_vsan_health_return_code = 1
                else: 
                    logger.info("VCA: Cluster %s Status: %s", vc_clusterName, clusterStatus.status)
               
                for hostStatus in clusterStatus.trackedHostsStatus:
                    if hostStatus.hostname == vc_source_host_name:
                        if "red" in hostStatus.status:
                            logger.error("Host %s Status: %s", hostStatus.hostname, hostStatus.status)
                            vca_vsan_health_return_code = 1
                        else:
                            logger.info("Host %s Status: %s", hostStatus.hostname, hostStatus.status)
                            vca_vsan_health_return_code = 0

                vsanTask = vhs.RepairClusterObjectsImmediate(cluster)
                vcTask = vsanapiutils.ConvertVsanTaskToVcTask(vsanTask, si._stub)
                vsanapiutils.WaitForTasks([vcTask], si)
                logger.info('VCA:Repairing cluster objects task completed with state: %s', vcTask.info.state)
                
            return vca_vsan_health_return_code

        except Exception as e:
            logging.error(
                ("Failed to execute the VCA vSAN health command. Exception occurred: %s"), e
            )
            sys.exit(1)     
        finally:
            Disconnect(si)

if __name__ == "__main__":
    return_code = 0
    try:
        if len(sys.argv) != 6:
            logger.error("Usage: python3 checkvSANHealth_service_vca.py <vcenter_ip> <username> <password> <cluster> <source_host_name>")
            sys.exit(1)

        vcenter_ip = sys.argv[1]
        username = sys.argv[2]
        password = sys.argv[3]
        cluster_name = sys.argv[4]
        source_host_name = sys.argv[5]
        
        if sys.argv[3]:
            password = sys.argv[3]
        else:
            password = getpass.getpass(
                prompt='Enter password for host %s and user %s: ' % (vcenter_ip, username)
            )

        return_code = CheckVCAvSANHealthService.check_vca_vsan_health(vcenter_ip, username, password, cluster_name, source_host_name)
        if return_code:
            logging.error("VCA: vSAN health status %s", {vcenter_ip})
            sys.exit(return_code)        

    except Exception as e:
        logging.error(
            "Execution failed, Could not complete vSAN health from VCA: %s", e
        )
        sys.exit(e)
