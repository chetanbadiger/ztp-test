# Copyright 2023 Hewlett Packard Enterprise Development LP
import argparse
import time
import logging
import sys
import paramiko

logging.basicConfig(filename='orchestrator.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
stream_handler = logging.StreamHandler()
logging.getLogger().addHandler(stream_handler)


class CheckvSANHealthService:
    """Class representing an automating ESXi Upgrade process"""
    def ssh_execute_command(ssh, command):
        """ Function printing executing ESXi CLI commands """
        _, stdout, stderr = ssh.exec_command(command)
        return stdout.read().decode(), stderr.read().decode()
   
    def check_vsan_health(host, username, password):
        """ Function returns the zero, 0 means vSAN health is green, 1 means vSAN health is red """
        vsan_health_return_bool = False
        vsan_health_return_code = 0
        vsan_health_error = None
        vsan_health_lst = []
        try:
            ssh_client = paramiko.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_client.connect(host, username=username, password=password)

            vsan_health_cmd =  "esxcli vsan health cluster list"
            vsan_health_report, vsan_health_error = CheckvSANHealthService.ssh_execute_command(ssh_client, vsan_health_cmd)
            time.sleep(30)

            if len(vsan_health_error) != 0:
                logging.error(f"Error on execute the vSAN health command {vsan_health_error}")
                sys.exit(1)
            
            for i, line in enumerate(vsan_health_report.splitlines()):
                    if "Physical disk" in line:
                        vsan_health_lst.append(line)
                    if "Cluster" in line:
                        vsan_health_lst.append(line)
                    if "Data" in line:
                        vsan_health_lst.append(line)
                    if "Performance service" in line:
                        vsan_health_lst.append(line)
     
            vsan_health_return_bool = all("green" in word for word in vsan_health_lst)
            if vsan_health_return_bool:
                vsan_health_return_code = 0
            else:
                vsan_health_return_code = 1
            return vsan_health_return_code, vsan_health_report
        
        except Exception as e:
            logging.error(
                ("Failed to execute the vSAN health command. Exception occurred: %s"), e
            )
            sys.exit(1)     
        finally:
            ssh_client.close()
       
if __name__ == "__main__":
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument("esxi_host")
        parser.add_argument("esxi_user")
        parser.add_argument("esxi_password")
        
        args = parser.parse_args()
    
        return_code = 0
            
        esxi_host = args.esxi_host
        esxi_user = args.esxi_user
        esxi_password = args.esxi_password
     
        return_code, vsan_health_report = CheckvSANHealthService.check_vsan_health(esxi_host, esxi_user, esxi_password)
        if return_code:
            logging.error(f"vSAN health status of Physical disk or Cluster or Data or Performance service is red for ESXi host {esxi_host}")
            logging.info(f"vSAN health status: \n {vsan_health_report}")
            sys.exit(return_code)
        
        logging.info(f"vSAN health status of Physical disk or Cluster or Data or Performance service are green for ESXi host {esxi_host}")


    except Exception as e:
        logging.error(
            "Execution failed, Could not complete upgrade for ESXi: %s", e
        )
        sys.exit(e)