import json
import logging
import os
import sys
import argparse
import subprocess
import time

logging.basicConfig(filename='orchestrator.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
stream_handler = logging.StreamHandler()
logging.getLogger().addHandler(stream_handler)


parser = argparse.ArgumentParser()
parser.add_argument('numberOfNodes')
parser.add_argument('store_json')
parser.add_argument('depot_file')
args = parser.parse_args()
NUMBER_OF_NODES = int(args.numberOfNodes)
store_json_file = args.store_json
depot_file = args.depot_file
VSAN_MAX_RETRIES = 10

def performEsxiUpgrade(temp_store_json):
    """

    :param temp_store_json: Temp store json
    :return:
    """
    try:
        logging.info("In perform esxi")
        servers = temp_store_json["servers"]
        for source_index in range(len(servers)):
            destination_index = (source_index + 1) % len(servers)
            #Script to migrate all vm on source host and put host on maintenance mode
            source_host = servers[source_index]
            destination_host = servers[destination_index]
            logging.info(f"Source host: {source_host['mgmtIP']}")
            logging.info(f"Destination host: {destination_host['mgmtIP']}")
            
            RETRIES = 0
            while( VSAN_MAX_RETRIES > RETRIES):
                retcode = subprocess.run(['python3', './checkvSANHealth_service.py', source_host['esxifqdn'], source_host['osusername'], source_host['osPassword']])
                if retcode.returncode != 0:
                    logging.error(f"vSAN Health is undesirable for {source_host['mgmtIP']}")
                    RETRIES = RETRIES + 1
                    time.sleep(60)
                else:
                    logging.info(f"{source_host['mgmtIP']} vSAN is in good state post upgrade")
                    break
            if RETRIES == VSAN_MAX_RETRIES:
                logging.error("vSAN Health is Undesirable....EXITING.......")
                sys.exit(1)
                
            retcode = subprocess.run(['python3', './maintenance_service.py', temp_store_json["vCenter"]["IP"],   temp_store_json["vCenter"]["username"], temp_store_json["vCenter"]["password"], source_host['esxifqdn'], source_host['localDataStore'], source_host['backupDataStore'], destination_host['esxifqdn']])
            if retcode.returncode != 0:
                logging.error(f"Error in running maintenance service for {source_host['mgmtIP']}")
                logging.info(retcode)
                sys.exit(retcode.returncode)
            else:
                logging.info(f"{source_host['mgmtIP']} is clear for upgrade")
                          

            #Script to perform upgrade and bring source host from maintenance mode
            depot_path = f"/vmfs/volumes/{source_host['localDataStore']}/depot_files/{depot_file}"
            retcode = subprocess.run(['python3', './upgradeESXI_service.py', source_host['mgmtIP'], source_host['osusername'], source_host['osPassword'], depot_path])
            
            if retcode.returncode != 0 :
                logging.error("Error in Upgrade Esxi service")
                logging.info(retcode)
                sys.exit(retcode.returncode)
            else:
                logging.info(f"ESxi upgrade successfully done for {source_host['mgmtIP']} ")
            logging.info("Waiting for cluster to Re-adjust")
            time.sleep(60)  

            #Script to perform exit maintenance mode after the ESXi upgrade
            retcode = subprocess.run(['python3', './exit_maintenance_service.py', temp_store_json["vCenter"]["IP"], temp_store_json["vCenter"]["username"], temp_store_json["vCenter"]["password"], source_host['esxifqdn'], source_host['localDataStore'], source_host['backupDataStore']])
            if retcode.returncode != 0:
                logging.error(f"Error in running exit maintenance service for {source_host['mgmtIP']}")
                logging.info(retcode)
                sys.exit(retcode.returncode)
            else:
                logging.info(f"{source_host['mgmtIP']} is clear for exit maintenance service")
            time.sleep(60)


            RETRIES = 0
            while( VSAN_MAX_RETRIES > RETRIES):
                retcode = subprocess.run(['python3', './checkvSANHealth_service.py', source_host['esxifqdn'], source_host['osusername'], source_host['osPassword']])
                if retcode.returncode != 0:
                    logging.error(f"vSAN Health is undesirable for {source_host['mgmtIP']}")
                    RETRIES = RETRIES + 1
                    time.sleep(60)
                else:
                    logging.info(f"{source_host['mgmtIP']} vSAN is in good state post upgrade")
                    break
            if RETRIES == VSAN_MAX_RETRIES:
                logging.error("vSAN Health is Undesirable....EXITING.......")
                sys.exit(1)
                
        logging.info("ESXI upgrade is successfull")

    except Exception as e:
        logging.error("Error in performing upgrade : %s", str(e))
        sys.exit(1)

if __name__ == "__main__":
    try:
        with open(store_json_file, "r") as json_file:
            store_json = json.load(json_file)
        
        store_ID = input(f"Type the store ID {store_json['storeID']} to proceed: ")
        if store_json['storeID'] == store_ID:
           print(f"Running ESXI upgrade for {store_json['storeID']}......") 
           performEsxiUpgrade(store_json)
        else:
            print("Upgrade cancelled")
        
    except Exception as e:
        logging.error("Error in Completing upgrade : %s", str(e))
        sys.exit(1)
